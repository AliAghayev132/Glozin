const mongoose = require("mongoose");
const Schema = mongoose.Schema;

/**
 * @swagger
 * components:
 *   schemas:
 *     Product:
 *       type: object
 *       properties:
 *         brand:
 *           type: string
 *           description: Ürün markası
 *         title:
 *           type: string
 *           description: Ürün başlığı
 *         price:
 *           type: number
 *           description: Ürün fiyatı
 *         discountedPrice:
 *           type: number
 *           nullable: true
 *           description: İndirimli fiyat (varsa)
 *         viewCount:
 *           type: number
 *           description: Ürün görüntüleme sayısı
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           description: Ürün bedenleri
 *         colors:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               img:
 *                 type: string
 *                 description: Renk resmi
 *               name:
 *                 type: string
 *                 description: Renk adı
 *         stock:
 *           type: number
 *           description: Ürün stoğu
 *         sku:
 *           type: string
 *           description: Ürün stok kodu
 *         description:
 *           type: string
 *           description: Ürün açıklaması
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Oluşturulma tarihi
 *         modifiedAt:
 *           type: string
 *           format: date-time
 *           description: Güncellenme tarihi
 */

const productSchema = new Schema(
  {
    brand: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    discountedPrice: {
      type: Number,
      default: null,
    },
    viewCount: {
      type: Number,
      default: 0,
    },
    sizes: {
      type: [String],
      required: true,
    },
    colors: [
      {
        img: { type: String, required: true },
        name: { type: String, required: true },
      },
    ],
    stock: {
      type: Number,
      required: true,
    },
    sku: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    modifiedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

const Product = mongoose.model("Product", productSchema);
module.exports = Product;
