const express = require("express");
const router = express.Router();
const productController = require("../../../controllers/productControllers");
const multer = require("multer");

// Configure storage settings
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./public/products/uploads"); // Set your upload directory
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname); // Rename the file
  },
});
const upload = multer({ storage });
/**
 * @swagger
 * tags:
 *   name: Products Admin
 *   description: Product management
 */
/**
 * @swagger
 * /api/admin/product:
 *   get:
 *     summary: Get all products
 *     tags: [Products Admin]
 *     responses:
 *       200:
 *         description: List of all products
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Product'  # Reference to Product schema
 *       500:
 *         description: Error retrieving products
 */
router.get("/", productController.getAllProducts);

router.get("/:id", productController.getProductById);
/**
 * @swagger
 * /api/admin/product/{id}:
 *   get:
 *     summary: Get a product by ID
 *     tags: [Products Admin]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Product ID
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Product found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Product'  # Reference to Product schema
 *       404:
 *         description: Product not found
 *       500:
 *         description: Error retrieving the product
 */
/**
 * @swagger
 * /api/admin/product:
 *   post:
 *     summary: Create a new product
 *     tags: [Products Admin]
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               brand:
 *                 type: string
 *                 description: Brand of the product
 *                 example: "Nike"
 *               title:
 *                 type: string
 *                 description: Title of the product
 *                 example: "Running Shoes"
 *               price:
 *                 type: number
 *                 description: Price of the product
 *                 example: 120.99
 *               discountedPrice:
 *                 type: number
 *                 description: Discounted price if available
 *                 example: 99.99
 *               sizes:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Available sizes for the product
 *                 example: ["S", "M", "L"]
 *               colors:
 *                 type: string
 *                 description: |
 *                   JSON string of available colors, e.g., '[{"name": "Red"}, {"name": "Blue"}]'
 *                 example: '[{"name": "Red"}, {"name": "Blue"}]'
 *               stock:
 *                 type: number
 *                 description: Stock quantity
 *                 example: 100
 *               sku:
 *                 type: string
 *                 description: Stock keeping unit
 *                 example: "SKU12345"
 *               description:
 *                 type: string
 *                 description: Detailed description of the product
 *                 example: "High-quality running shoes for daily workouts."
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: Product image file to be uploaded
 *     responses:
 *       201:
 *         description: Product created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Product'
 *       400:
 *         description: Validation error or missing required fields
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "All required fields must be provided"
 *       500:
 *         description: Error creating the product
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Error creating product"
 *                 error:
 *                   type: string
 */
router.post("/", upload.single("file"), productController.createProduct);

/**
 * @swagger
 * /api/admin/product/{id}:
 *   put:
 *     summary: Update an existing product
 *     tags: [Products Admin]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Product ID
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ProductInput'  # Reference to Product input schema
 *     responses:
 *       200:
 *         description: Product updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Product'  # Reference to Product schema
 *       404:
 *         description: Product not found
 *       500:
 *         description: Error updating the product
 */
router.put("/:id", productController.updateProduct);

/**
 * @swagger
 * /api/admin/product/{id}:
 *   delete:
 *     summary: Delete a product
 *     tags: [Products Admin]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Product ID
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Product deleted
 *       404:
 *         description: Product not found
 *       500:
 *         description: Error deleting the product
 */
router.delete("/:id", productController.deleteProduct);

module.exports = router;
