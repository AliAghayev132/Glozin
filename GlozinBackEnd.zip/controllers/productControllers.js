const Product = require("../schemas/Product");

// Get all products
exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    return res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: "Ürünler alınırken hata oluştu.", error });
  }
};

// Get a single product by ID
exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Ürün bulunamadı." });
    return res.status(200).json(product);
  } catch (error) {
    res.status(500).json({ message: "Ürün alınırken hata oluştu.", error });
  }
};

// Create a new product

// Create a new product with in-function validation and file upload
exports.createProduct = async (req, res) => {
  console.log(req.body); // Should log the form fields
  console.log(req.file); // Should log the uploaded file info if any

  const {
    brand,
    title,
    price,
    discountedPrice,
    sizes,
    colors,
    stock,
    sku,
    description,
  } = req.body;

  console.log({
    brand,
    title,
    price,
    discountedPrice,
    sizes,
    colors,
    stock,
    sku,
    description,
  });

  // Check for missing fields
  if (
    !brand ||
    !title ||
    !price ||
    !sizes ||
    !colors ||
    !stock ||
    !sku ||
    !description
  ) {
    return res
      .status(400)
      .json({ message: "All required fields must be provided" });
  }

  // Parse the `colors` JSON string if needed
  let parsedColors;
  try {
    parsedColors = JSON.parse(colors);
    if (!Array.isArray(parsedColors) || parsedColors.some((c) => !c.name)) {
      return res
        .status(400)
        .json({ message: "Each color must have a 'name' property" });
    }
  } catch (error) {
    return res.status(400).json({ message: "Invalid format for colors" });
  }

  // Handle the color images with the uploaded file
  const colorsWithImages = parsedColors.map((color) => ({
    name: color.name,
    img: req.file ? `/public/products/uploads/${req.file.filename}` : null,
  }));

  try {
    const newProduct = new Product({
      brand,
      title,
      price,
      discountedPrice,
      sizes,
      colors: colorsWithImages,
      stock,
      sku,
      description,
    });
    const savedProduct = await newProduct.save();
    return res.status(201).json(savedProduct);
  } catch (error) {
    return res.status(500).json({ message: "Error creating product", error });
  }
};
// Update an existing product
exports.updateProduct = async (req, res) => {
  const {
    brand,
    title,
    price,
    discountedPrice,
    viewCount,
    sizes,
    colors,
    stock,
    sku,
    description,
  } = req.body;

  try {
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      {
        brand,
        title,
        price,
        discountedPrice,
        viewCount,
        sizes,
        colors,
        stock,
        sku,
        description,
      },
      { new: true }
    );

    if (!updatedProduct)
      return res.status(404).json({ message: "Ürün bulunamadı." });
    res.status(200).json(updatedProduct);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Ürün güncellenirken hata oluştu.", error });
  }
};

// Delete a product
exports.deleteProduct = async (req, res) => {
  try {
    const deletedProduct = await Product.findByIdAndDelete(req.params.id);
    if (!deletedProduct)
      return res.status(404).json({ message: "Ürün bulunamadı." });
    res.status(200).json({ message: "Ürün başarıyla silindi." });
  } catch (error) {
    res.status(500).json({ message: "Ürün silinirken hata oluştu.", error });
  }
};
